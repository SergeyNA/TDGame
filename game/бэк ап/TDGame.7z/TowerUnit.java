package TDGame;

import java.awt.Graphics2D;
import java.awt.Image;
import java.util.List;

public class TowerUnit {

	private int x;
	private int y;
	private Image[] towerImage;
	private int animation;
	private int animationDelay;
	private int attack;
	private int range;
	private int cd;
	private int cdStatus;
	//private int attackType;
	//private int damageType;
	//private boolean splash;
	private int ammo;
	private int xC;
	private int yC;

	// �������� �y������ � ��� ����� !!!!!!!!!!
	// ��������� �������� � ������������ ��������!!!!!!!!!!!!!!!!!!!

	public TowerUnit(Image[] img, int xCoord, int yCoord, int damage, int dist, int cooldown, int ammoCount) {

		this.towerImage = img;
		this.x = xCoord;
		this.y = yCoord;
		this.animation = 0;
		this.animationDelay = (int) (Math.random() * 35);
		this.attack = damage;
		this.range = dist;
		this.cd = cooldown;
		this.cdStatus = cooldown;
		this.ammo = ammoCount;
		this.xC = xCoord + img[0].getWidth(null) / 2;
		this.yC = yCoord + img[0].getHeight(null) / 2;

	}

	public int getWidth() {
		return towerImage[0].getWidth(null);
	}

	public int getHeight() {
		return towerImage[0].getHeight(null);
	}

	public void draw(Graphics2D g) {

		g.drawImage(towerImage[this.animation], this.x, this.y, null);
		g.drawOval(this.xC - this.range, this.yC - this.range, this.range * 2, this.range * 2);
		//g.drawOval(this.xC - this.range, this.yC - this.range, this.range * 2 + 1, this.range * 2 + 1);

		this.animationDelay++;
		this.animationDelay %= 35;
		this.animation = this.animationDelay / 7;

	}

	public void kill(List<EnemyUnit> enemies, List<Shell> shells) {
		int ammoCount = this.ammo;
		if(this.cdStatus == this.cd) {
			for (EnemyUnit enemy : enemies) {
				if (enemy.getState()) {
					if(ammoCount > 0) {
						int xDist = enemy.getXC() - this.xC;
						int yDist = enemy.getYC() - this.yC;
						if (xDist * xDist + yDist * yDist < this.range * this.range) {
							enemy.applyDamage(this.attack);
							shells.add(new Shell(this.xC, this.yC, enemy.getXC(), enemy.getYC(), 10, 0));
							ammoCount--;
						}
					}						
				}
			}
			if(ammoCount != this.ammo) {
				this.cdStatus = 0;
			}
		}
		if(this.cdStatus != this.cd) {
			this.cdStatus++;
		}
	}

}
